How to use (Unity 2022.3.34f1):
1) Unzip into your Unity project's ROOT so that 'Assets/' merges with your Assets folder.
2) In Unity, open: Assets/_Project/Scenes/XR_BaseScene.unity
3) You will immediately see the full hierarchy in the Hierarchy panel.
4) Install XR packages (XR Interaction Toolkit, OpenXR, Input System) as needed.