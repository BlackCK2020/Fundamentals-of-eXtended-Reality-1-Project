﻿using System;
using System.ComponentModel;

namespace Unity.PlasticSCM.Editor.CollabMigration
{
    // Placeholder. This isn't a public API.
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Obsolete("MigrateCollabProject is deprecated and will be removed in a future release", false)]
    public static class MigrateCollabProject
    {
    }
}
